package com.example.BookLink

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class SeleccioPerfil : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val PantallaInici= Intent (this, PaginaInici::class.java)
        val PantallaConfig= Intent (this, PaginaConfig::class.java)
        setContent {
            Column(
                modifier = Modifier.fillMaxSize().background(Color(0xFFF0EBE3)),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.SpaceEvenly
            ) {
                Column(
                    modifier = Modifier
                        .background(Color(0xFFF0EBE3))
                        .padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = "Escull el teu perfil",
                        fontSize = 40.sp,
                        fontFamily = FontFamily(Font(R.font.abrilfatface)),
                        color = Color(0XFF576F72),
                    )
                    Button(
                        onClick = {startActivity(PantallaConfig)},
                        modifier = Modifier
                            .height(70.dp)
                            .width(350.dp)
                            .padding(5.dp)
                    ) {
                        Text(text = "Soc professor/a")
                    }
                    Button(
                        onClick = {startActivity(PantallaInici)},
                        modifier = Modifier
                            .height(70.dp)
                            .width(350.dp)
                            .padding(5.dp)
                    ) {
                        Text(text = "Soc alumne/a")
                    }
                }
                Image(
                    painter = painterResource(id = R.drawable.dibuixet),
                    contentDescription = "Logo",
                    modifier = Modifier.size(400.dp) // Adjust the size as needed
                )
            }
        }
    }
}