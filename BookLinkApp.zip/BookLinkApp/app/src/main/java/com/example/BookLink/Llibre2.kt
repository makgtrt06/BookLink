package com.example.BookLink

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Text
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class Llibre2 : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xFFF0EBE3)),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Top
            ){
                Text(text = "Detalls del llibre",
                    fontSize = 25.sp,
                    fontFamily = FontFamily(Font(R.font.syne)),
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(20.dp)
                )
                Row {
                    Card(
                        modifier = Modifier
                            .width(170.dp)
                            .height(300.dp)
                            .padding(horizontal = 5.dp, vertical = 20.dp)
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.invisible),
                            contentDescription = null,
                            contentScale = ContentScale.FillBounds,
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                    Box(
                        modifier = Modifier
                            .padding(20.dp)
                            .align(Alignment.Top) // Aligning the Box to center vertically within the Row
                    ) {
                        Column {
                            //-------------------------------TÍTOL I AUTOR/A
                            Text(
                                text = "Invisible",
                                fontSize = 22.sp,
                                fontFamily = FontFamily(Font(R.font.syne))
                            )
                            Text(
                                text = "Eloy Moreno",
                                fontSize = 15.sp,
                                fontFamily = FontFamily(Font(R.font.syne)),
                                color = Color(0XFF7D9D9C)
                            )
                            //-------------------------------IDIOMA
                            Text(
                                text = "Idioma: Castellà",
                                fontSize = 15.sp,
                                fontFamily = FontFamily(Font(R.font.syne)),
                                modifier = Modifier.padding(vertical = 20.dp)
                            )
                            //-------------------------------VALORACIÓ
                            Text(
                                text = "Valoració: 5/5",
                                fontSize = 15.sp,
                                fontFamily = FontFamily(Font(R.font.syne)),
                                color = Color(0XFF576F72)
                            )
                            //-------------------------------ETIQUETES (filtres)
                            Row(Modifier.padding(vertical = 50.dp)){
                                Card (
                                    modifier = Modifier
                                        .height(50.dp)
                                        .width(50.dp)
                                        .align(Alignment.CenterVertically)
                                ){
                                    Box(
                                        modifier = Modifier.fillMaxSize(),
                                        contentAlignment = Alignment.Center // Aligns the text in the center of the box
                                    ) {
                                        Text(
                                            text = "Social",
                                            color = Color.Black, // Specify the text color
                                            style = TextStyle(
                                                textAlign = TextAlign.Center // Center the text horizontally
                                            ),
                                            fontSize = 15.sp,
                                            fontFamily = FontFamily(Font(R.font.syne))
                                        )
                                    }
                                }
                                Card (
                                    modifier = Modifier
                                        .height(50.dp)
                                        .width(70.dp)
                                        .align(Alignment.CenterVertically)
                                        .padding(horizontal = 10.dp)
                                ){
                                    Box(
                                        modifier = Modifier.fillMaxSize(),
                                        contentAlignment = Alignment.Center // Aligns the text in the center of the box
                                    ) {
                                        Text(
                                            text = "Juvenil",
                                            color = Color.Black, // Specify the text color
                                            style = TextStyle(
                                                textAlign = TextAlign.Center // Center the text horizontally
                                            ),
                                            fontSize = 15.sp,
                                            fontFamily = FontFamily(Font(R.font.syne))
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
                //-------------------------------DESCRIPCIÓ
                Text(text = "Descripció",
                    fontSize = 20.sp,
                    fontFamily = FontFamily(Font(R.font.syne)),
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(bottom = 10.dp)
                )
                Text(text = "Emotiva, commovedora, diferent... Invisible narra a través dels ulls d'un nen, una història que podria ser la de qualsevol de nosaltres. Qui no ha volgut mai ser invisible? Qui no ha desitjat mai deixar ser-ho? El problema és que mai he arribat a controlar bé aquest poder: De vegades, quan més ganes tenia de ser invisible, era quan més gent em veia, i en canvi, quan desitjava que tothom em veiés, era quan al meu cos li donava per desaparèixer.",
                    modifier = Modifier.padding(horizontal = 35.dp),
                    fontSize = 15.sp,
                    fontFamily = FontFamily(Font(R.font.syne))
                )
                Spacer(modifier = Modifier.padding(80.dp))
                Button(
                    onClick = {/*TODO*/},
                    modifier = Modifier
                        .padding(16.dp)
                        .width(400.dp)
                        .height(45.dp),
                ) {
                    Text(text = "Reservat",
                        fontSize = 20.sp,
                        fontFamily = FontFamily(Font(R.font.syne)),
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }
    }
}