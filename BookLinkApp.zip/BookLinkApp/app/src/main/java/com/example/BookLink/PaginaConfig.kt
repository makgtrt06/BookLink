package com.example.BookLink

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.BottomAppBar
import androidx.compose.material3.BottomAppBarDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.FloatingActionButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.BookLink.ui.theme.Prova2Theme

class PaginaConfig : ComponentActivity() {
    @OptIn(ExperimentalMaterial3Api::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Get the aspect ratio of the image (width / height)
        val aspectRatio1 = 993f / 1500f
        val aspectRatio2 = 650f / 1011f
        val aspectRatio3 = 641f / 1000f
        val aspectRatio4 = 649f / 1000f

        // Calculate the height of the card based on the aspect ratio
        val cardHeight1 = (170.dp / aspectRatio1)
        val cardHeight2 = (170.dp / aspectRatio2)
        val cardHeight3 = (170.dp / aspectRatio3)
        val cardHeight4 = (170.dp / aspectRatio4)

        //Variable canvi de pantalla
        val CanviLlibre1= Intent (this, Llibre1::class.java)
        val CanviLlibre2= Intent (this, Llibre2::class.java)
        val CanviLlibre3= Intent (this, Llibre3::class.java)
        val CanviLlibre4= Intent (this, Llibre4::class.java)

        val CanviEscaneig= Intent (this, Escaneig::class.java)

        setContent {
            Column (modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFFF0EBE3)),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Top)
            {
                Card (modifier = Modifier
                    .width(350.dp)
                    .height(170.dp)
                    .padding(vertical = 40.dp))
                {
                    Row {
                        Column {
                            Text(
                                text = "Benvingut a BookLink!",
                                fontSize = 15.sp,
                                fontFamily = FontFamily(Font(R.font.syne)),
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 25.dp, vertical = 15.dp)
                            )
                            Text(
                                text = "Digitalitza la biblioteca de l'escola!",
                                fontSize = 15.sp,
                                fontFamily = FontFamily(Font(R.font.syne)),
                                fontWeight = FontWeight.Normal,
                                modifier = Modifier.padding(horizontal = 25.dp)
                            )
                        }
                        Image(
                            painter = painterResource(id = R.drawable.llibres), // Replace "your_image" with your image resource ID
                            contentDescription = null, // You can add a content description if needed
                            contentScale = ContentScale.FillBounds,
                            modifier = Modifier
                                .fillMaxSize()
                        )
                    }
                }
                Text(text = "Afegits recentment",
                    fontSize = 20.sp,
                    fontFamily = FontFamily(Font(R.font.syne)),
                    fontWeight = FontWeight.Medium,
                )
                Box (modifier = Modifier      //----------------------------------------VISTA LLIBRES
                    .align(Alignment.CenterHorizontally)
                    .verticalScroll(rememberScrollState())
                    .padding(vertical = 20.dp)
                ){
                    Column {
                        Row (modifier = Modifier
                            .padding(vertical = 10.dp)
                        ){
                            Card(
                                colors = CardDefaults.cardColors(
                                    containerColor = Color(0XFFE4DCCF)
                                ),
                                modifier = Modifier
                                    .width(170.dp) // Width of the card remains constant
                                    .height(cardHeight1) // Height of the card is calculated dynamically
                                    .padding(horizontal = 5.dp),
                                onClick = {startActivity(CanviLlibre1)}
                            ) {
                                Image(
                                    painter = painterResource(id = R.drawable.happyplace), // Replace "your_image" with your image resource ID
                                    contentDescription = null, // You can add a content description if needed
                                    contentScale = ContentScale.FillBounds,
                                    modifier = Modifier
                                        .fillMaxSize()
                                )
                            }
                            Card(
                                colors = CardDefaults.cardColors(
                                    containerColor = Color(0XFFE4DCCF),
                                ),
                                modifier = Modifier
                                    .width(170.dp) // Width of the card remains constant
                                    .height(cardHeight2) // Height of the card is calculated dynamically
                                    .padding(horizontal = 5.dp),
                                onClick = {startActivity(CanviLlibre2)}

                            ) {
                                Image(
                                    painter = painterResource(id = R.drawable.invisible), // Replace "your_image" with your image resource ID
                                    contentDescription = null, // You can add a content description if needed
                                    contentScale = ContentScale.FillBounds,
                                    modifier = Modifier
                                        .fillMaxSize()
                                )
                            }
                        }
                        Row {
                            Card(
                                colors = CardDefaults.cardColors(
                                    containerColor = Color(0XFFE4DCCF),
                                ),
                                modifier = Modifier
                                    .width(170.dp) // Width of the card remains constant
                                    .height(cardHeight3) // Height of the card is calculated dynamically
                                    .padding(horizontal = 5.dp),
                                onClick = {/*TODO*/}

                            ) {
                                Image(
                                    painter = painterResource(id = R.drawable.thehouseoftheceruleansea), // Replace "your_image" with your image resource ID
                                    contentDescription = null, // You can add a content description if needed
                                    contentScale = ContentScale.FillBounds,
                                    modifier = Modifier
                                        .fillMaxSize()
                                )
                            }
                            Card(
                                colors = CardDefaults.cardColors(
                                    containerColor = Color(0XFFE4DCCF),
                                ),
                                modifier = Modifier
                                    .width(170.dp) // Width of the card remains constant
                                    .height(cardHeight4) // Height of the card is calculated dynamically
                                    .padding(horizontal = 5.dp),
                                onClick = {/*TODO*/}

                            ) {
                                Image(
                                    painter = painterResource(id = R.drawable.janeeyre), // Replace "your_image" with your image resource ID
                                    contentDescription = null, // You can add a content description if needed
                                    contentScale = ContentScale.FillBounds,
                                    modifier = Modifier
                                        .fillMaxSize()
                                )
                            }
                        }
                    }
                }
                // MENÚ INFERIOR - Crida de la funció
                BottomAppBarExample(CanviEscaneig)
            }
        }
    }


    //Declaració de la funció del menú inferior
    @Composable
    fun BottomAppBarExample(CanviEscaneig:Intent) {
        Scaffold(
            bottomBar = {
                BottomAppBar(
                    actions = {
                        Column (
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Top
                        ){
                            IconButton(onClick = { /* do something */ }) {
                                Icon(Icons.Filled.Favorite, contentDescription = "Localized description")
                            }
                            Text(text = "Reserves",
                                fontSize = 10.sp,
                                fontFamily = FontFamily(Font(R.font.syne)),
                            )
                        }

                        Column (
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Top
                        ){
                            IconButton(onClick = { /* do something */ }) {
                                Icon(Icons.Filled.Send, contentDescription = "Localized description")
                            }
                            Text(text = "Fòrums",
                                fontSize = 10.sp,
                                fontFamily = FontFamily(Font(R.font.syne)),
                            )
                        }

                        Column (
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Top
                        ){
                            IconButton(onClick = { /* do something */ }) {
                                Icon(Icons.Filled.Edit, contentDescription = "Localized description")
                            }
                            Text(text = "Tests",
                                fontSize = 10.sp,
                                fontFamily = FontFamily(Font(R.font.syne)),
                            )
                        }
                        Column (
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Top
                        ){
                            IconButton(onClick = { /* do something */ }) {
                                Icon(Icons.Filled.Search, contentDescription = "Localized description")
                            }
                            Text(text = "Cercador",
                                fontSize = 10.sp,
                                fontFamily = FontFamily(Font(R.font.syne)),
                            )
                        }
                    },
                    floatingActionButton = {
                        FloatingActionButton(
                            onClick = {startActivity(CanviEscaneig)},
                            containerColor = BottomAppBarDefaults.bottomAppBarFabColor,
                            elevation = FloatingActionButtonDefaults.bottomAppBarFabElevation()
                        ) {
                            Icon(Icons.Filled.Add, "Localized description")
                        }
                    },

                )
            },
        ) { innerPadding ->
            Text(
                modifier = Modifier.padding(innerPadding),
                text = "Menú inferior"
            )
        }
    }
}