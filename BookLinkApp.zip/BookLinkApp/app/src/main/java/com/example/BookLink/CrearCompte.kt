package com.example.BookLink

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class CrearCompte : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val PantallaPerfils= Intent (this, SeleccioPerfil::class.java)
        setContent {
            var correu by remember { mutableStateOf(" ") }
            var username by remember { mutableStateOf(" ") }
            var psswd1 by remember { mutableStateOf(" ") }
            var psswd2 by remember { mutableStateOf(" ") }
            Column(
                //Fons de color
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xFFF0EBE3)),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,

                ){
                Image(
                    painter = painterResource(id = R.drawable.logopetit),
                    contentDescription = "Logo",
                    modifier = Modifier
                        .size(90.dp)
                )
                Text(text = "Crear un compte",
                    fontSize = 40.sp,
                    fontFamily = FontFamily(
                        Font(R.font.abrilfatface)
                    ),
                    color = (Color(0XFF576F72)))

                TextField(value = correu,
                    onValueChange = {correu = it},
                    label= {Text (text = "Correu",
                        fontFamily = FontFamily(Font(R.font.syne)))})
                TextField(value = username,
                    onValueChange = {username = it},
                    label= {Text (text = "Nom d'usuari",
                        fontFamily = FontFamily(Font(R.font.syne)))})
                TextField(value = psswd1,
                    onValueChange = {psswd1 = it},
                    label= {Text (text = "Contrasenya",
                        fontFamily = FontFamily(Font(R.font.syne)))})
                TextField(value = psswd2,
                    onValueChange = {psswd2 = it},
                    label= {Text (text = "Verificar contrasenya",
                        fontFamily = FontFamily(Font(R.font.syne)))})
                Button(
                    onClick = { startActivity(PantallaPerfils)
                    }) {
                    Text(text = "Començar",
                        fontFamily = FontFamily(Font(R.font.syne)))
                }
            }
        }
    }
}