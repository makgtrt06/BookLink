package com.example.BookLink

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.paddingFromBaseline
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class PantallaSeleccio : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val PantallaCrear= Intent (this, CrearCompte::class.java)
        val PantallaPerfils= Intent (this, SeleccioPerfil::class.java)

        setContent {
            var id by remember { mutableStateOf(" ") }
            var psswd by remember { mutableStateOf(" ") }
            Column(
                //Fons de color
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xFFF0EBE3)),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,

                ){
                Image(
                    painter = painterResource(id = R.drawable.logopetit),
                    contentDescription = "Logo",
                    modifier = Modifier
                        .size(90.dp)
                )
                Text(text = "Iniciar sessió",
                    fontSize = 40.sp,
                    fontFamily = FontFamily(
                        Font(R.font.abrilfatface)),
                    color = (Color(0XFF576F72)),
                )
                OutlinedTextField(value = id,
                    onValueChange = {id = it},
                    label= {Text (text = "Correu / Nom d'usuari",
                        fontFamily = FontFamily(Font(R.font.syne)))},
                    shape = RoundedCornerShape(16.dp) // Adjust the radius as needed
                )
                OutlinedTextField(value = psswd,
                    onValueChange = {psswd = it},
                    label= {Text (text = "Contrasenya",
                        fontFamily = FontFamily(Font(R.font.syne)))},
                    shape = RoundedCornerShape(16.dp) // Adjust the radius as needed
                )
                Button(
                    onClick = {startActivity(PantallaPerfils) }) {
                    Text(text = "Inciar sessió",
                        fontFamily = FontFamily(Font(R.font.syne)))
                }
                Row (Modifier.paddingFromBaseline(top = 130.dp)){
                    Text(text = "No tens un compte? ",
                        fontFamily = FontFamily(
                            Font(R.font.syne))
                    )
                    Text(
                        text = "Crea'n un.",
                        Modifier.clickable {
                            startActivity(PantallaCrear)},
                        fontFamily = FontFamily(
                            Font(R.font.syne)),
                        color = (Color(0XFF7D9D9C))
                    )

                }
            }
        }
    }
}